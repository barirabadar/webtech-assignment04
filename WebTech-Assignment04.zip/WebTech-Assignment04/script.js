// ---------- 1. Grab the elements we need ----------
var markdownInput = document.getElementById("markdownInput");
var previewContent = document.getElementById("previewContent");
var previewCount = document.getElementById("previewCount");
var presentContent = document.getElementById("presentContent");
var presentCount = document.getElementById("presentCount");
var presentationScreen = document.getElementById("presentation-screen");
var message = document.getElementById("message");

var previewLeft = document.getElementById("previewLeft");
var previewRight = document.getElementById("previewRight");
var previewFull = document.getElementById("previewFull");
var presentLeft = document.getElementById("presentLeft");
var presentRight = document.getElementById("presentRight");
var presentFull = document.getElementById("presentFull");

// ---------- 2. Variables that remember things ----------
var currentSlide = 0;                 // which slide we are on (0 = first)
var storageKey = "mySlides";          // name used to save in the browser

var starterText =
  "# This is Slide 01\n" +
  "## This is Heading 02 in slide 01\n\n" +
  "This is your content on slide 01\n\n" +
  "---\n" +
  "# This is Slide 02\n" +
  "## This is Heading 02 in slide 02\n\n" +
  "This is your content on slide 02\n\n" +
  "---\n" +
  "# This is Slide 03\n\n" +
  "- Use the arrow keys to change slides\n" +
  "- Press Ctrl+S to save\n";

// ---------- 3. Split the markdown into slides ----------
function getSlides() {
  // every "---" line starts a new slide
  var parts = markdownInput.value.split(/^---$/m);
  var slides = [];
  for (var i = 0; i < parts.length; i++) {
    var text = parts[i].trim();
    if (text !== "") {
      slides.push(text);
    }
  }
  if (slides.length === 0) {
    slides.push("");
  }
  return slides;
}

// ---------- 4. Show the current slide ----------
function showSlide() {
  var slides = getSlides();

  // make sure currentSlide is never out of range
  if (currentSlide > slides.length - 1) {
    currentSlide = slides.length - 1;
  }
  if (currentSlide < 0) {
    currentSlide = 0;
  }

  // turn markdown into HTML
  var html = marked.parse(slides[currentSlide]);
  var countText = (currentSlide + 1) + " / " + slides.length;

  // put it in BOTH the preview and the presentation screen
  previewContent.innerHTML = html;
  presentContent.innerHTML = html;
  previewCount.textContent = countText;
  presentCount.textContent = countText;

  // disable Left on first slide, Right on last slide
  var onFirst = (currentSlide === 0);
  var onLast = (currentSlide === slides.length - 1);
  previewLeft.disabled = onFirst;
  presentLeft.disabled = onFirst;
  previewRight.disabled = onLast;
  presentRight.disabled = onLast;

  // change the full screen button text
  var text = document.fullscreenElement ? "Exit Full Screen" : "Full Screen";
  previewFull.textContent = text;
  presentFull.textContent = text;
}

// ---------- 5. Move left and right ----------
function goLeft() {
  currentSlide = currentSlide - 1;
  showSlide();
}

function goRight() {
  currentSlide = currentSlide + 1;
  showSlide();
}

// ---------- 6. Full screen ----------
function toggleFullScreen() {
  if (document.fullscreenElement) {
    document.exitFullscreen();            // leave full screen
  } else {
    presentationScreen.classList.remove("hidden");   // show presentation
    presentationScreen.requestFullscreen();          // go full screen
  }
}

function openPresentation() {
  presentationScreen.classList.remove("hidden");
  presentationScreen.requestFullscreen();
  showSlide();
}

function closePresentation() {
  if (document.fullscreenElement) {
    document.exitFullscreen();
  }
  presentationScreen.classList.add("hidden");
  showSlide();
}

// ---------- 7. Save and load (browser memory = localStorage) ----------
function saveSlides() {
  localStorage.setItem(storageKey, markdownInput.value);
  message.textContent = "Saved!";
}

function loadSlides() {
  var saved = localStorage.getItem(storageKey);
  if (saved !== null) {
    markdownInput.value = saved;     // use what we saved last time
  } else {
    markdownInput.value = starterText;   // first time: show an example
  }
}

function newSlides() {
  markdownInput.value = starterText;
  currentSlide = 0;
  showSlide();
  message.textContent = "New slides created (press Save to keep them)";
}

// ---------- 8. Connect buttons to functions ----------
document.getElementById("newBtn").onclick = newSlides;
document.getElementById("saveBtn").onclick = saveSlides;
document.getElementById("presentBtn").onclick = openPresentation;
document.getElementById("closeBtn").onclick = closePresentation;

previewLeft.onclick = goLeft;
presentLeft.onclick = goLeft;
previewRight.onclick = goRight;
presentRight.onclick = goRight;
previewFull.onclick = toggleFullScreen;
presentFull.onclick = toggleFullScreen;

// update the preview every time you type
markdownInput.oninput = function () {
  message.textContent = "";
  showSlide();
};

// update button text when full screen starts or stops
document.onfullscreenchange = function () {
  if (!document.fullscreenElement) {
    presentationScreen.classList.add("hidden");
  }
  showSlide();
};

// ---------- 9. Keyboard keys ----------
document.onkeydown = function (event) {
  // Ctrl+S = save
  if (event.ctrlKey && event.key.toLowerCase() === "s") {
    event.preventDefault();        // stop the browser's own save
    saveSlides();
  }

  // F11 = full screen
  if (event.key === "F11") {
    event.preventDefault();
    toggleFullScreen();
  }

  // arrow keys = change slide
  // (inside the text box, hold Alt so the arrows can still move the cursor)
  var typing = (document.activeElement === markdownInput);
  var presenting = !presentationScreen.classList.contains("hidden");

  if (!typing || presenting || event.altKey) {
    if (event.key === "ArrowRight") {
      event.preventDefault();
      if (currentSlide < getSlides().length - 1) {
        goRight();
      }
    }
    if (event.key === "ArrowLeft") {
      event.preventDefault();
      if (currentSlide > 0) {
        goLeft();
      }
    }
  }
};

// ---------- 10. Start the app ----------
loadSlides();
showSlide();